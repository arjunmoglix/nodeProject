const mysql = require('mysql');
const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '12345',
    database: 'ecommerce'
  });

module.exports = (app) => {
  app.get('/cart', (req, res) => {
    let sql = "SELECT * FROM products INNER JOIN carts ON products.id = carts.product_id";
      let query = conn.query(sql, (err, results) => {
        if(err) throw err;
        res.render('checkout/cart',{
          results: results
        });
      });
    });
  app.get('/add-to-cart/:id', (req, res) => {
    
    // const id = req.params.id;

   let data = {product_id:req.params.id};
  let sql = "INSERT INTO carts SET ?";
  let query = conn.query(sql, data,(err, results) => {
    if(err) throw err;
    res.redirect('/');
  });
  });
 


  app.post('/deletecart/:id',(req, res) => {
    res.send("hii");
      let sql = "DELETE FROM carts WHERE id="+req.params.id;
      let query = conn.query(sql, (err, results) => {
        if(err) throw err;
          res.redirect('/');
      });
    });

    app.get('/category/:id', (req, res) => {

      let sql = "SELECT * FROM products WHERE category="+req.params.id;
      let query = conn.query(sql, (err, products) => {
        if(err) throw err;
        res.render('home/index',{
        products: products
        });
      });
    });
    app.get('/aboutUs',(req,res)=>{
      res.render('checkout/aboutUs')

    });
    app.get('/add-to-favorite/:id',(req,res)=>{
  
      let data = {product_id:req.params.id};
        let sql = "INSERT INTO wishlist SET ?";
        let query = conn.query(sql, data,(err, results) => {
          if(err) throw err;
          res.redirect('/');
        });
        });

        app.get('/wishlist', (req, res) => {
          let sql = "SELECT * FROM products INNER JOIN wishlist ON products.id = wishlist.product_id";
            let query = conn.query(sql, (err, results) => {
              if(err) throw err;
              res.render('checkout/wishList',{
                results: results
              });
            });
          });  

          app.get('/contact',(req,res)=>{
            res.render('checkout/contact')
      
          });
          app.get('/search', (req, res) => {
            console.log(req.body.search);
    
            let sql = "SELECT * from products where name LIKE '$%{req.body.search}%'";
      let query = conn.query(sql, (err, products) => {
        if(err) throw err;
        res.render('home/index',{
        products: products
        });
      });
    });

};

